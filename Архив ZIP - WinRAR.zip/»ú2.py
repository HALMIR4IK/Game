import os
import random
import sys

import pygame
c = 0
x, y = 0, 0
def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


WIDTH = 500
HEIGHT = 500
FPS = 30

# Задаем цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)


class Bomb(pygame.sprite.Sprite):
    def __init__(self, *group):
        super().__init__(*group)
        pygame.sprite.Sprite.__init__(self)
        self.image = player_img
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(50, WIDTH - 50)
        self.rect.y = random.randrange(50, HEIGHT - 50)


    def update(self):
        self.rect = self.rect.move(random.randrange(3) - 1,
                                   random.randrange(3) - 1)
        if self.rect.x + 25 > x > self.rect.x - 25 and self.rect.y + 25 > y > self.rect.y - 25:
            self.image = boom
# Создаем игру и окно

pygame.quit()
if __name__ == '__main__':
    pygame.init()
    pygame.mixer.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    screen.fill(BLUE)
    pygame.display.set_caption("My Game")
    player_img = load_image('bomb.png')
    boom = load_image('boom.png')
    player_img = pygame.transform.scale(player_img, (50, 50))
    clock = pygame.time.Clock()
    all_sprites = pygame.sprite.Group()
    player = Bomb()
    all_sprites.add(player)
    for _ in range(50):
        Bomb(all_sprites)
    pygame.display.flip()

    running = True
    while running:
        # Держим цикл на правильной скорости
        clock.tick(FPS)
        # Ввод процесса (события)
        for event in pygame.event.get():
            # check for closing window
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos

                all_sprites.update()
                # Рендеринг


                screen.fill(BLUE)
                all_sprites.draw(screen)
                # После отрисовки всего, переворачиваем экран
                pygame.display.flip()
                clock.tick(400)
    pygame.quit()
